import { Check, UserRound } from "lucide-react";
import { useState } from "react";
import { Button, Field, PageHeader, SectionCard, inputClass } from "@/components/app-ui";
import { segments, useCampusData, type Segment } from "@/lib/campus-data";

export function TeacherProfilePage({ admin = false }: { admin?: boolean }) {
  const { teacher, updateTeacher } = useCampusData();
  const [form, setForm] = useState({ ...teacher });
  const [saved, setSaved] = useState(false);
  const showSubject = form.segment === "Fundamental 2" || form.segment === "Ensino Médio";

  return (
    <div className="animate-rise space-y-7">
      <PageHeader eyebrow={admin ? "Administração · Usuários" : "Área do professor · Primeiro cadastro"} title={admin ? "Professores" : "Meu perfil"} description="Informe o seguimento em que você dará aula. Esse cadastro filtra automaticamente as salas e turmas disponíveis na nova reserva." />
      <SectionCard title="Dados do professor" eyebrow="Cadastro local">
        <form className="max-w-xl space-y-5 p-5 sm:p-6" onSubmit={(event) => { event.preventDefault(); updateTeacher(form); setSaved(true); window.setTimeout(() => setSaved(false), 2200); }} data-testid="form-teacher-profile">
          <div className="flex items-center gap-3 rounded-xl bg-[hsl(var(--muted)/.45)] p-4"><span className="grid h-10 w-10 place-items-center rounded-xl bg-[hsl(var(--primary)/.1)] text-[hsl(var(--primary))]"><UserRound size={19} /></span><div><p className="text-sm font-semibold">Perfil usado nas reservas</p><p className="text-xs text-[hsl(var(--muted-foreground))]">O nome abaixo será preenchido automaticamente.</p></div></div>
          <Field label="Nome do professor"><input required value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} className={inputClass} placeholder="Ex.: Marina Lopes" data-testid="input-teacher-name" /></Field>
          <Field label="Seguimento"><select value={form.segment} onChange={(event) => setForm({ ...form, segment: event.target.value as Segment, subject: "" })} className={inputClass} data-testid="select-teacher-segment">{segments.map((segment) => <option key={segment} value={segment}>{segment}</option>)}</select></Field>
          {showSubject ? <Field label="Matéria" hint="Obrigatória para Fundamental 2 e Ensino Médio."><input required value={form.subject} onChange={(event) => setForm({ ...form, subject: event.target.value })} className={inputClass} placeholder="Ex.: Ciências" data-testid="input-teacher-subject" /></Field> : <p className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--muted)/.3)] p-3 text-xs leading-5 text-[hsl(var(--muted-foreground))]">Para Educação Infantil e Fundamental 1, a sala cadastrada pela administração será exibida diretamente na reserva.</p>}
          <div className="flex justify-end border-t border-[hsl(var(--border))] pt-4"><Button type="submit" data-testid="button-save-teacher-profile"><Check size={15} /> {saved ? "Cadastro salvo" : "Salvar cadastro"}</Button></div>
        </form>
      </SectionCard>
    </div>
  );
}