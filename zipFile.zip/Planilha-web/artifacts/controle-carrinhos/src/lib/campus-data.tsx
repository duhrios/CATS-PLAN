import { createContext, useContext, useMemo, useState, type ReactNode } from "react";
import { todayISO } from "@/components/app-ui";

export const segments = ["Educação Infantil", "Fundamental 1", "Fundamental 2", "Ensino Médio"] as const;
export type Segment = (typeof segments)[number];
export type ReservationKind = "Aula" | "Reserva";

export type TeacherProfile = {
  name: string;
  segment: Segment;
  subject: string;
};

export type Reservation = {
  id: number;
  teacher: string;
  segment: Segment;
  subject: string;
  className: string;
  room: string;
  period: "Manhã" | "Tarde";
  date: string;
  start: string;
  end: string;
  cart: string;
  status: "Confirmada" | "Aguardando" | "Concluída";
  kind: ReservationKind;
  quantity: number;
};

export type Cart = {
  id: string;
  name: string;
  code: string;
  prefix: string;
  total: number;
  available: number;
  location: string;
  status: string;
  lastCheck: string;
  accent: string;
  unavailable: boolean;
  reserveCapacity: number;
};

const teacherStorageKey = "controle-carrinhos-teacher";
const reservationStorageKey = "controle-carrinhos-reservations";
const cartStorageKey = "controle-carrinhos-carts";

export const defaultTeacher: TeacherProfile = {
  name: "Marina Lopes",
  segment: "Fundamental 2",
  subject: "Ciências",
};

export const initialReservations: Reservation[] = [
  { id: 1, teacher: "Marina Lopes", segment: "Fundamental 2", subject: "Ciências", className: "8º ano B · Ciências", room: "Laboratório 02", period: "Manhã", date: todayISO(), start: "07:40", end: "09:20", cart: "Carrinho A", status: "Confirmada", kind: "Aula", quantity: 30 },
  { id: 2, teacher: "Rafael Nunes", segment: "Fundamental 2", subject: "Matemática", className: "7º ano A · Matemática", room: "Sala 14", period: "Manhã", date: todayISO(), start: "09:40", end: "11:20", cart: "Carrinho B", status: "Confirmada", kind: "Aula", quantity: 30 },
  { id: 3, teacher: "Bianca Reis", segment: "Fundamental 2", subject: "Geografia", className: "9º ano C · Geografia", room: "Sala 21", period: "Manhã", date: todayISO(), start: "10:00", end: "11:40", cart: "Carrinho A", status: "Aguardando", kind: "Aula", quantity: 30 },
  { id: 4, teacher: "Caio Martins", segment: "Fundamental 1", subject: "Português", className: "6º ano A · Português", room: "Sala 08", period: "Tarde", date: "2025-03-19", start: "13:30", end: "15:10", cart: "Carrinho C", status: "Concluída", kind: "Aula", quantity: 25 },
  { id: 5, teacher: "Lívia Costa", segment: "Fundamental 2", subject: "História", className: "8º ano A · História", room: "Sala 18", period: "Manhã", date: "2025-03-20", start: "08:00", end: "09:40", cart: "Carrinho C", status: "Confirmada", kind: "Aula", quantity: 30 },
];

export const initialCarts: Cart[] = [
  { id: "a", name: "Carrinho A", code: "A", prefix: "A", total: 60, available: 55, location: "Armário A · Bloco 1", status: "Pronto", lastCheck: "Hoje, 06:52", accent: "bg-[hsl(var(--primary))]", unavailable: false, reserveCapacity: 0 },
  { id: "b", name: "Carrinho B", code: "B", prefix: "B", total: 58, available: 54, location: "Armário B · Bloco 1", status: "Pronto", lastCheck: "Hoje, 06:48", accent: "bg-[hsl(var(--accent))]", unavailable: false, reserveCapacity: 10 },
  { id: "c", name: "Carrinho C", code: "C", prefix: "C", total: 55, available: 51, location: "Armário C · Bloco 2", status: "Em uso", lastCheck: "Hoje, 06:41", accent: "bg-[hsl(158_43%_43%)]", unavailable: false, reserveCapacity: 10 },
];

function readStorage<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const saved = window.localStorage.getItem(key);
    return saved ? JSON.parse(saved) as T : fallback;
  } catch {
    return fallback;
  }
}

type CampusDataValue = {
  teacher: TeacherProfile;
  updateTeacher: (profile: TeacherProfile) => void;
  reservations: Reservation[];
  saveReservation: (data: Omit<Reservation, "id" | "status">, id?: number) => void;
  carts: Cart[];
  addCart: (cart: Omit<Cart, "id">) => void;
  toggleCartUnavailable: (id: string) => void;
  toggleCartMaintenance: (id: string) => void;
  reserveAvailable: number;
  teacherReserved: number;
};

const CampusDataContext = createContext<CampusDataValue | null>(null);

export function CampusDataProvider({ children }: { children: ReactNode }) {
  const [teacher, setTeacher] = useState<TeacherProfile>(() => readStorage(teacherStorageKey, defaultTeacher));
  const [reservations, setReservations] = useState<Reservation[]>(() => readStorage<Partial<Reservation>[]>(reservationStorageKey, initialReservations).map((item) => ({ ...item, segment: item.segment ?? "Fundamental 2", subject: item.subject ?? "", kind: item.kind ?? "Aula", quantity: item.quantity ?? 1 }) as Reservation));
  const [carts, setCarts] = useState<Cart[]>(() => readStorage<Partial<Cart>[]>(cartStorageKey, initialCarts).map((cart) => ({ ...cart, unavailable: cart.unavailable ?? false, reserveCapacity: cart.reserveCapacity ?? (cart.code === "B" || cart.code === "C" ? 10 : 0) }) as Cart));

  const persistTeacher = (next: TeacherProfile) => {
    setTeacher(next);
    window.localStorage.setItem(teacherStorageKey, JSON.stringify(next));
  };
  const persistReservations = (next: Reservation[]) => {
    setReservations(next);
    window.localStorage.setItem(reservationStorageKey, JSON.stringify(next));
  };
  const persistCarts = (next: Cart[]) => {
    setCarts(next);
    window.localStorage.setItem(cartStorageKey, JSON.stringify(next));
  };

  const saveReservation = (data: Omit<Reservation, "id" | "status">, id?: number) => {
    const next = id
      ? reservations.map((item) => item.id === id ? { ...item, ...data } : item)
      : [{ ...data, id: Math.max(...reservations.map((item) => item.id), 0) + 1, status: "Aguardando" as const }, ...reservations];
    persistReservations(next);
  };

  const toggleCartUnavailable = (id: string) => {
    persistCarts(carts.map((cart) => cart.id === id ? { ...cart, unavailable: !cart.unavailable, status: !cart.unavailable ? "Indisponível" : "Pronto" } : cart));
  };
  const addCart = (cart: Omit<Cart, "id">) => {
    persistCarts([...carts, { ...cart, id: `cart-${cart.code.toLowerCase()}-${carts.length + 1}` }]);
  };
  const toggleCartMaintenance = (id: string) => {
    persistCarts(carts.map((cart) => cart.id === id ? { ...cart, status: cart.status === "Manutenção" ? "Pronto" : "Manutenção" } : cart));
  };

  const reserveAvailable = useMemo(() => carts.reduce((total, cart) => total + cart.reserveCapacity, 0) - reservations.filter((item) => item.kind === "Reserva").reduce((total, item) => total + item.quantity, 0), [carts, reservations]);
  const teacherReserved = useMemo(() => reservations.filter((item) => item.kind === "Reserva" && item.teacher === teacher.name).reduce((total, item) => total + item.quantity, 0), [reservations, teacher.name]);

  return <CampusDataContext.Provider value={{ teacher, updateTeacher: persistTeacher, reservations, saveReservation, carts, addCart, toggleCartUnavailable, toggleCartMaintenance, reserveAvailable, teacherReserved }}>{children}</CampusDataContext.Provider>;
}

export function useCampusData() {
  const value = useContext(CampusDataContext);
  if (!value) throw new Error("useCampusData must be used inside CampusDataProvider");
  return value;
}